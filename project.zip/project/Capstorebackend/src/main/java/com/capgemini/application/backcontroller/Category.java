package com.capgemini.application.backcontroller;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
