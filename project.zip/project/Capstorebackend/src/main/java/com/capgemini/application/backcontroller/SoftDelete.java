package com.capgemini.application.backcontroller;

public enum SoftDelete {
	Activated, Deactivated
}
