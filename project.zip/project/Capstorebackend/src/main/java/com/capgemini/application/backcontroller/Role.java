package com.capgemini.application.backcontroller;

public enum Role {
	Customer,Admin,Merchant
}
