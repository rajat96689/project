package com.capgemini.application.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
