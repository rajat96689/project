package com.capgemini.application.beans;

public enum Role {
	Customer,Admin,Merchant
}
