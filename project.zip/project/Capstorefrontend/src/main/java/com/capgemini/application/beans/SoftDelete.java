package com.capgemini.application.beans;

public enum SoftDelete {
	Activated, Deactivated
}
