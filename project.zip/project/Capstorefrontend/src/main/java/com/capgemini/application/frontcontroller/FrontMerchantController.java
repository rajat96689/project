package com.capgemini.application.frontcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FrontMerchantController {

	//Merchant page Request mapping 
	
	
	/*@RequestMapping("/")
	public String homepage() {
		return "MerchantIndex";	
	}*/
	
	@RequestMapping("/index")
	public String indexpageofmerchant() {
		return "MerchantIndex";
	}
	

	@RequestMapping("/logout")
	public String logoutpage() {
		return "Merchant-login";
	}
	
	@RequestMapping("/merchantprofile")
	public String profile() {
		return "merchant-profile";
	}
	@RequestMapping("/manageinventory")
	public String inventory() {
		return "Manage-Inventory";
	}
	
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addProduct";
	}
	@RequestMapping("/deleteproduct")
	public String deleteproduct() {
		return "deleteproduct";
	}
	
	@RequestMapping("/viewinventory")
	public String ViewInventory() {
		return "viewinventory";
	}
	
	@RequestMapping("/checkorder")
	public String Checkorder() {
		return "Checkorder";
	}
	

	@RequestMapping("/updatestock")
	public String UpdateStock() {
		return "updateStock";
	}
	
	
	@RequestMapping("/category")
	public String Category() {
		return "category";
	}
	
	//Customer Mapping 
	
	@RequestMapping("/customerindex")
	public String indexpageofcustomer() {
		return "CustomerIndex";
	}
	
	@RequestMapping("/customerprofile")
	public String CustomerProfile() {
		return "Customerprofile";
	}
	
	@RequestMapping("/cart")
	public String CustomerCart() {
		return "Customercart";
	}
	
	@RequestMapping("/")
	public String CustomerIndex() {
		return "CustomerIndex";
	}
	
	@RequestMapping("wishlist")
	public String CustomerWishlist() {
		return "CustomerWishlist";
	}
	
	
	@RequestMapping("feedback")
	public String CustomerFeedback() {
		return "CustomerFeedback";
	}
	

	@RequestMapping("/customerlogout")
	public String Customerlogout() {
		return "CustomerHomepage";
	}
	
	@RequestMapping("/customeredit")
	public String CustomereditProfile() {
		return "CustomerEditProfile";
	}
	
	}
