package com.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;



@Repository
@Transactional
public class RepoRestImpl implements RepoRest {
@PersistenceContext	
private EntityManager entityManager;
	@Override
	public List<Merchant> findAll() {
		
		Query query = entityManager.createQuery("select merchant from Merchant merchant");
		return query.getResultList();
	}
	@Override
	public List<Customer> findAllCustomer() {
		Query query = entityManager.createQuery("select customer from Customer customer");
		return query.getResultList();
	}

}
