
  package com.capstore.controller;
  
  import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import
  org.springframework.web.bind.annotation.RequestMapping;
import
  org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.dto.Customer;

import com.capstore.dto.Merchant;

import com.capstore.repo.RepoRestImpl;
  
  @RestController
  @RequestMapping("rest")
  public class AdminRestController {
	  @Autowired
	  RepoRestImpl daoRef;
  
  @RequestMapping(method=RequestMethod.GET,value="/merchantList") 
 public List<Merchant> show(){
	  System.out.println("in merchant");
	return daoRef.findAll();
	  
  }
  @RequestMapping(method=RequestMethod.GET,value="/customerList") 
  public List<Customer> showCustomers(){
 	  System.out.println("in customer");
 	return daoRef.findAllCustomer();
 	  
   }
  
  }
 
