
  package com.capstore.controller;
  
  import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import
  org.springframework.web.bind.annotation.RequestMapping;
import
  org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;

//import com.capstore.dto.MerchantDto;
  
  @Controller
  public class AdminController {
  
  @RequestMapping(method=RequestMethod.GET,value="admin") 
  public String index() {
	  return "admin";
  }
  @RequestMapping(method=RequestMethod.GET,value="/merchantdetails") 
  public String merchant(ModelMap modelMap) {
	  RestTemplate restTemplate = new RestTemplate();
	  List<Merchant> response = new ArrayList<Merchant>();
     response = restTemplate.getForObject("http://localhost:7799/rest/merchantList", List.class);
     modelMap.put("merchantList",response);
	  return "merchantDetails";
  } 
  @RequestMapping(method=RequestMethod.GET,value="/customerdetails") 
  public String customer(ModelMap modelMap) {
	  RestTemplate restTemplate = new RestTemplate();
	  List<Customer> response = new ArrayList<Customer>();
     response = restTemplate.getForObject("http://localhost:7799/rest/customerList", List.class);
     modelMap.put("customerList",response);
	  return "customerDetails";
  } 
  @RequestMapping(method=RequestMethod.GET,value="/addMerchant") 
  public String addNewMerchant() {
	return null;
	  
  }
  
  
  }
 
