package com.capgemini.application.frontcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FrontController {

	
	@RequestMapping("/")
	public String homepage() {
		return "MerchantIndex";	
	}
	

	
	@RequestMapping("/index")
	public String indexpageofmerchant() {
		return "MerchantIndex";
	}
	

	@RequestMapping("/logout")
	public String logoutpage() {
		return "Merchant-login";
	}
	
	@RequestMapping("/merchantprofile")
	public String profile() {
		return "merchant-profile";
	}
	@RequestMapping("/manageinventory")
	public String inventory() {
		return "Manage-Inventory";
	}
	
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addProduct";
	}
	@RequestMapping("/deleteproduct")
	public String deleteproduct() {
		return "deleteproduct";
	}
	
	@RequestMapping("/viewinventory")
	public String ViewInventory() {
		return "viewinventory";
	}
	
	}
