package com.capgemini.application.frontcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FrontController {

	
	@RequestMapping("/")
	public String homepage() {
		return "MerchantIndex";	
	}
	
	@RequestMapping("/merchantprofile")
	public String profile() {
		return "merchant-profile";
	}
	@RequestMapping("/manageinventory")
	public String inventory() {
		return "Manage-Inventory";
	}
	
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addProduct";
	}
	
	}
